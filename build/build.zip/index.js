'use strict';

require('./public/css/index.scss');